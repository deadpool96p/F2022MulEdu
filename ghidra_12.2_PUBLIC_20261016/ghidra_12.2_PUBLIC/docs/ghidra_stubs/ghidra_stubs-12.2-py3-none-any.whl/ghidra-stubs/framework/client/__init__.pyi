from __future__ import annotations
import collections.abc
import datetime
import typing
from warnings import deprecated # type: ignore

import jpype # type: ignore
import jpype.protocol # type: ignore

import db.buffers
import docking.widgets
import ghidra.framework.model
import ghidra.framework.remote
import ghidra.framework.store
import ghidra.security
import ghidra.util.task
import java.awt # type: ignore
import java.io # type: ignore
import java.lang # type: ignore
import java.net # type: ignore
import java.util # type: ignore
import javax.security.auth.callback # type: ignore
import javax.swing.event # type: ignore


class AbstractUrlAllowListProvider(UrlAllowListProvider):
    """
    :obj:`AbstractUrlAllowListProvider` provides the abstract URL allow list provider.
    
    
    NOTE: See :obj:`UrlAllowListManager` for persistent allow list which will be consulted before
    prompting user and updated if user allows access.
    """

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self) -> None:
        ...


class UrlAllowListProvider(java.lang.Object):
    """
    :obj:`UrlAllowListProvider` provides the URL allow list provider interface which facilitates
    obtaining an access decision for a specified server URL.
    """

    class_: typing.ClassVar[java.lang.Class]

    def isAllowed(self, url: java.net.URL) -> bool:
        """
        Check if a server connection is permitted.  If permitted, the server will be added
        to the cached allow list.  This method will return true for opaque or non-server URLs.
        
        :param java.net.URL url: server URL
        :return: true if connection is allowed and may proceed, else false if denied
        :rtype: bool
        """

    @property
    def allowed(self) -> jpype.JBoolean:
        ...


class AccessRecord(java.lang.Record):
    """
    :obj:`AccessRecord` provides the URL Allow List access record used by
    :obj:`UrlAllowListManager`.
    
    
    .. seealso::
    
        | :obj:`java.lang.System.currentTimeMillis()`
    """

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, accessAllowed: typing.Union[jpype.JBoolean, bool], time: typing.Union[jpype.JLong, int]) -> None:
        ...

    def accessAllowed(self) -> bool:
        ...

    def equals(self, o: java.lang.Object) -> bool:
        ...

    def hashCode(self) -> int:
        ...

    def time(self) -> int:
        ...

    def toString(self) -> str:
        ...


class ClientAuthenticator(ghidra.security.KeyStorePasswordProvider):

    class_: typing.ClassVar[java.lang.Class]

    def getAuthenticator(self) -> java.net.Authenticator:
        """
        Get a standard Java authenticator for HTTP and other standard network connections
        
        :return: authenticator object
        :rtype: java.net.Authenticator
        """

    def getNewPassword(self, parent: java.awt.Component, serverInfo: typing.Union[java.lang.String, str], username: typing.Union[java.lang.String, str]) -> jpype.JArray[jpype.JChar]:
        """
        Get new user password
        
        :param java.awt.Component parent: dialog parent component or null if not applicable
        :param java.lang.String or str serverInfo: server host info
        :param java.lang.String or str username: 
        :return: new password or null if password should not be changed, 
        if not null array will be cleared by caller
        :rtype: jpype.JArray[jpype.JChar]
        """

    def isSSHKeyAvailable(self) -> bool:
        """
        
        
        :return: true if SSH private key is available for authentication
        :rtype: bool
        """

    def processPasswordCallbacks(self, title: typing.Union[java.lang.String, str], serverType: typing.Union[java.lang.String, str], serverName: typing.Union[java.lang.String, str], allowUserNameEntry: typing.Union[jpype.JBoolean, bool], nameCb: javax.security.auth.callback.NameCallback, passCb: javax.security.auth.callback.PasswordCallback, choiceCb: javax.security.auth.callback.ChoiceCallback, anonymousCb: ghidra.framework.remote.AnonymousCallback, loginError: typing.Union[java.lang.String, str]) -> bool:
        """
        Process password authentication callbacks.
        
        :param java.lang.String or str title: password prompt title if GUI is used
        :param java.lang.String or str serverType: type of server (label associated with serverName)
        :param java.lang.String or str serverName: name of server
        :param jpype.JBoolean or bool allowUserNameEntry: if true user ID entry will be supported if nameCb is not null.
        :param javax.security.auth.callback.NameCallback nameCb: provides storage for user login name.  A null indicates
        that the default user name will be used, @see ClientUtil#getUserName()
        :param javax.security.auth.callback.PasswordCallback passCb: provides storage for user password, @see PasswordCallback#setPassword(char[])
        :param javax.security.auth.callback.ChoiceCallback choiceCb: specifies choice between NT Domain authentication (index=0) and local password
        file authentication (index=1).  Set selected index to specify authenticator to be used,
        :param ghidra.framework.remote.AnonymousCallback anonymousCb: may be used to request anonymous read-only access to 
        the server.  A null is specified if anonymous access has not been enabed on the server.
        :param java.lang.String or str loginError: previous login error message or null for first attempt
        :return: true if password provided, false if entry cancelled
        :rtype: bool
        
        .. seealso::
        
            | :obj:`ChoiceCallback.setSelectedIndex(int)`A null is specified if no choice is available (password authenticator determined by server configuration).
        
            | :obj:`AnonymousCallback.setAnonymousAccessRequested(boolean)`
        """

    def processSSHSignatureCallbacks(self, serverName: typing.Union[java.lang.String, str], nameCb: javax.security.auth.callback.NameCallback, sshCb: ghidra.framework.remote.SSHSignatureCallback) -> bool:
        """
        Process Ghidra Server SSH authentication callbacks.
        
        :param java.lang.String or str serverName: name of server
        :param javax.security.auth.callback.NameCallback nameCb: provides storage for user login name.  A null indicates
        that the default user name will be used, @see ClientUtil#getUserName().
        :param ghidra.framework.remote.SSHSignatureCallback sshCb: provides authentication token to be signed with private key, @see SSHAuthenticationCallback#sign(SSHPrivateKey)
        :return: 
        :rtype: bool
        """

    def promptForReconnect(self, parent: java.awt.Component, message: typing.Union[java.lang.String, str]) -> bool:
        """
        Prompt user for reconnect
        
        :param java.awt.Component parent: dialog parent component or null if not applicable
        :param java.lang.String or str message: 
        :return: return true if reconnect should be attempted
        :rtype: bool
        """

    @property
    def sSHKeyAvailable(self) -> jpype.JBoolean:
        ...

    @property
    def authenticator(self) -> java.net.Authenticator:
        ...


class ClientUtil(java.lang.Object):
    """
    ``ClientUtil`` allows a user to connect to a Repository Server and obtain its handle.
    """

    class_: typing.ClassVar[java.lang.Class]

    @staticmethod
    def changePassword(parent: java.awt.Component, handle: ghidra.framework.remote.RepositoryServerHandle, serverInfo: typing.Union[java.lang.String, str]) -> None:
        """
        Prompt user and change password on server (not initiated by user).
        
        :param java.awt.Component parent: dialog parent
        :param ghidra.framework.remote.RepositoryServerHandle handle: server handle
        :param java.lang.String or str serverInfo: server information
        :raises IOException: if error occurs while updating password
        """

    @staticmethod
    def checkGhidraServer(host: typing.Union[java.lang.String, str], port: typing.Union[jpype.JInt, int], monitor: ghidra.util.task.TaskMonitor) -> None:
        """
        Connect to a Ghidra Server and verify compatibility.  This method can be used
        to effectively "ping" the Ghidra Server to verify the ability to connect.
        NOTE: Use of this method when PKI authentication is enabled is not supported.
        
        :param java.lang.String or str host: server hostname
        :param jpype.JInt or int port: first Ghidra Server port (0=use default)
        :param ghidra.util.task.TaskMonitor monitor: cancellable monitor
        :raises IOException: thrown if an IO Error occurs (e.g., server not found).
        :raises RemoteException: if server interface is incompatible or another server-side
        error occurs.
        :raises CancelledException: if connection attempt was cancelled
        """

    @staticmethod
    def clearRepositoryAdapter(host: typing.Union[java.lang.String, str], port: typing.Union[jpype.JInt, int]) -> None:
        """
        Eliminate the specified repository server from the connection cache
        
        :param java.lang.String or str host: host name or IP address
        :param jpype.JInt or int port: port (0: use default port)
        """

    @staticmethod
    def getAllowListProvider() -> UrlAllowListProvider:
        """
        Get the currently installed GhidraURL allow list provider.  If one has not been
        installed, this will trigger the installation of a default instance.  The provider
        facilitates prompting the user if supported and returning a final allow or deny
        indication when accessing a URL.
        
        :return: current allow list provider
        :rtype: UrlAllowListProvider
        """

    @staticmethod
    def getClientAuthenticator() -> ClientAuthenticator:
        """
        Get the currently installed client authenticator.  If one has not been
        installed, this will trigger the installation of a default instance.
        
        :return: current client authenticator
        :rtype: ClientAuthenticator
        """

    @staticmethod
    @typing.overload
    def getRepositoryServer(host: typing.Union[java.lang.String, str], port: typing.Union[jpype.JInt, int]) -> RepositoryServerAdapter:
        """
        Connect to a Repository Server and obtain a handle to it.
        Based upon the server authentication requirements, the user may be
        prompted for a password via a Swing dialog.  If a previous connection
        attempt to this server failed, the adapter may be returned in a
        disconnected state.
        
        
        NOTE: Requesting a Ghidra Server adapter using this method will automatically
        add the server to the Server Allow List.
        
        :param java.lang.String or str host: server name or address
        :param jpype.JInt or int port: server port, 0 indicates that default port should be used.
        :return: repository server adapter
        :rtype: RepositoryServerAdapter
        """

    @staticmethod
    @typing.overload
    def getRepositoryServer(host: typing.Union[java.lang.String, str], port: typing.Union[jpype.JInt, int], forceConnect: typing.Union[jpype.JBoolean, bool]) -> RepositoryServerAdapter:
        """
        Connect to a Repository Server and obtain a handle to it.
        Based upon the server authentication requirements, the user may be
        prompted for a password via a Swing dialog.
        
        
        NOTE: Requesting a Ghidra Server adapter using this method will automatically
        add the server to the Server Allow List.
        
        :param java.lang.String or str host: server name or address
        :param jpype.JInt or int port: server port, 0 indicates that default port should be used.
        :param jpype.JBoolean or bool forceConnect: if true and the server adapter is disconnected, an
        attempt will be made to reconnect.
        :return: repository server handle
        :rtype: RepositoryServerAdapter
        """

    @staticmethod
    def getUserName() -> str:
        """
        Returns default user login name.  Actual user name used by repository
        should be obtained from RepositoryServerAdapter.getUser
        
        :return: default user name
        :rtype: str
        """

    @staticmethod
    @typing.overload
    def handleException(repository: RepositoryAdapter, exc: java.lang.Exception, operation: typing.Union[java.lang.String, str], mustRetry: typing.Union[jpype.JBoolean, bool], parent: java.awt.Component) -> None:
        """
        Displays an error dialog appropriate for the given exception. If the exception is a
        ConnectException or NotConnectedException, a prompt to reconnect to the Ghidra Server
        is displayed.
        
        :param RepositoryAdapter repository: may be null if the exception is not a RemoteException
        :param java.lang.Exception exc: exception that occurred
        :param java.lang.String or str operation: operation that was being done when the exception occurred; this string
        is be used in the message for the error dialog if one should be displayed
        :param jpype.JBoolean or bool mustRetry: true if the message should state that the user should retry the operation
        because it may not have succeeded (if the exception was because a RemoteException); there
        may be cases where the operation succeeded; as a result of the operation, a bad connection
        to the server was detected (e.g., save a file). Note: this parameter is ignored if the
        exception is not a ConnectException or NotConnectedException.
        :param java.awt.Component parent: parent of the error dialog
        """

    @staticmethod
    @typing.overload
    def handleException(repository: RepositoryAdapter, exc: java.lang.Exception, operation: typing.Union[java.lang.String, str], parent: java.awt.Component) -> None:
        """
        Displays an error dialog appropriate for the given exception. If the exception is a
        ConnectException or NotConnectedException, a prompt to reconnect to the Ghidra Server
        is displayed. The message states that the operation may have to be retried due to the
        failed connection.
        
        :param RepositoryAdapter repository: may be null if the exception is not a RemoteException
        :param java.lang.Exception exc: exception that occurred
        :param java.lang.String or str operation: operation that was being done when the exception occurred; this string
        is be used in the message for the error dialog if one should be displayed
        :param java.awt.Component parent: parent of the error dialog
        """

    @staticmethod
    def isConnected(host: typing.Union[java.lang.String, str], port: typing.Union[jpype.JInt, int]) -> bool:
        """
        Determine if a connected :obj:`RepositoryServerAdapter` already exists for the specified server.
        
        :param java.lang.String or str host: server name or address
        :param jpype.JInt or int port: server port, 0 indicates that default port applies.
        :return: true if connection already exists, else false
        :rtype: bool
        """

    @staticmethod
    def isSSHKeyAvailable() -> bool:
        ...

    @staticmethod
    def promptForReconnect(repository: RepositoryAdapter, parent: java.awt.Component) -> None:
        """
        Prompt the user to reconnect to the Ghidra Server.
        
        :param RepositoryAdapter repository: repository to connect to
        :param java.awt.Component parent: parent of the dialog
        """

    @staticmethod
    def setAllowListProvider(provider: UrlAllowListProvider) -> None:
        """
        Set client allow list provider for GhidraURL connections.
        
        :param UrlAllowListProvider provider: allow list provider
        """

    @staticmethod
    def setClientAuthenticator(authenticator: ClientAuthenticator) -> None:
        """
        Set client authenticator
        
        :param ClientAuthenticator authenticator: client authenticator instance
        """


class RepositoryServerAdapter(java.lang.Object):
    """
    ``RepositoryServerAdapter`` provides a persistent wrapper for a 
    ``RepositoryServerHandle`` which may become invalid if the 
    remote connection were to fail.
    """

    class_: typing.ClassVar[java.lang.Class]

    def addListener(self, listener: RemoteAdapterListener) -> None:
        """
        Add a listener to this remote adapter
        
        :param RemoteAdapterListener listener:
        """

    def anonymousAccessAllowed(self) -> bool:
        """
        
        
        :return: true if server allows anonymous access.
        Individual repositories must grant anonymous access separately.
        :rtype: bool
        :raises IOException: 
        :raises NotConnectedException: if server connection is down (user already informed)
        
        .. seealso::
        
            | :obj:`ghidra.framework.remote.RemoteRepositoryServerHandle.anonymousAccessAllowed()`
        """

    def canSetPassword(self) -> bool:
        """
        Returns true if this server allows the user to change their password.
        
        
        .. seealso::
        
            | :obj:`ghidra.framework.remote.RemoteRepositoryServerHandle.canSetPassword()`
        """

    def connect(self) -> bool:
        """
        Attempt to connect or re-connect to the server.
        
        :return: true if connect successful, false if cancelled by user
        :rtype: bool
        :raises NotConnectedException: if connect failed (error will be displayed to user)
        """

    def createRepository(self, name: typing.Union[java.lang.String, str]) -> RepositoryAdapter:
        """
        Create a new repository on the server.
        
        :param java.lang.String or str name: repository name.
        :return: handle to new repository.
        :rtype: RepositoryAdapter
        :raises DuplicateNameException: 
        :raises UserAccessException: 
        :raises IOException: 
        :raises NotConnectedException: if server connection is down (user already informed)
        
        .. seealso::
        
            | :obj:`ghidra.framework.remote.RemoteRepositoryServerHandle.createRepository(String)`
        """

    def deleteRepository(self, name: typing.Union[java.lang.String, str]) -> None:
        """
        Delete a repository.
        
        :param java.lang.String or str name: repository name.
        :raises UserAccessException: 
        :raises IOException: 
        :raises NotConnectedException: if server connection is down (user already informed)
        
        .. seealso::
        
            | :obj:`ghidra.framework.remote.RemoteRepositoryServerHandle.deleteRepository(java.lang.String)`
        """

    def disconnect(self) -> None:
        """
        Force disconnect with server
        """

    def getAllUsers(self) -> jpype.JArray[java.lang.String]:
        """
        Returns a list of all known users.
        
        :raises IOException: 
        :raises NotConnectedException: if server connection is down (user already informed)
        
        .. seealso::
        
            | :obj:`ghidra.framework.remote.RemoteRepositoryServerHandle.getAllUsers()`
        """

    def getLastConnectError(self) -> java.lang.Throwable:
        """
        Returns the last error associated with a failed connection attempt.
        
        :return: last connect error or null
        :rtype: java.lang.Throwable
        """

    def getRepository(self, name: typing.Union[java.lang.String, str]) -> RepositoryAdapter:
        """
        Get a handle to an existing repository.  The repository adapter is
        initially disconnected - the connect() method or another repository 
        action method must be invoked to establish a repository connection.
        
        :param java.lang.String or str name: repository name.
        :return: repository handle or null if repository not found.
        :rtype: RepositoryAdapter
        """

    def getRepositoryNames(self) -> jpype.JArray[java.lang.String]:
        """
        Returns a list of all repository names defined to the server.
        
        :raises IOException: 
        :raises NotConnectedException: if server connection is down (user already informed)
        
        .. seealso::
        
            | :obj:`ghidra.framework.remote.RemoteRepositoryServerHandle.getRepositoryNames()`
        """

    def getServerInfo(self) -> ghidra.framework.model.ServerInfo:
        """
        Returns server information.  May be null if using fixed RepositoryServerHandle.
        """

    def getUser(self) -> str:
        """
        Returns user's server login identity
        """

    def isCancelled(self) -> bool:
        """
        Returns true if the connection was cancelled by the user.
        
        :return: try if cancelled by user
        :rtype: bool
        """

    def isConnected(self) -> bool:
        """
        Returns true if connected.
        """

    def isReadOnly(self) -> bool:
        """
        
        
        :return: true if user has restricted read-only access to server (e.g., anonymous user)
        :rtype: bool
        :raises IOException: 
        :raises NotConnectedException: if server connection is down (user already informed)
        
        .. seealso::
        
            | :obj:`ghidra.framework.remote.RemoteRepositoryServerHandle.isReadOnly()`
        """

    def removeListener(self, listener: RemoteAdapterListener) -> None:
        """
        Remove a listener from this remote adapter
        
        :param RemoteAdapterListener listener:
        """

    def setPassword(self, saltedSHA256PasswordHash: jpype.JArray[jpype.JChar]) -> bool:
        """
        Set the simple password for the user.
        
        :param jpype.JArray[jpype.JChar] saltedSHA256PasswordHash: hex character representation of salted SHA256 hash of the password
        :return: true if password changed
        :rtype: bool
        :raises IOException: if user data can't be written to file
        :raises NotConnectedException: if server connection is down (user already informed)
        
        .. seealso::
        
            | :obj:`ghidra.framework.remote.RemoteRepositoryServerHandle.setPassword(char[])`
        
            | :obj:`generic.hash.HashUtilities.getSaltedHash(String, char[])`HashUtilities.getSaltedHash("SHA-256", char[])
        """

    @property
    def connected(self) -> jpype.JBoolean:
        ...

    @property
    def serverInfo(self) -> ghidra.framework.model.ServerInfo:
        ...

    @property
    def allUsers(self) -> jpype.JArray[java.lang.String]:
        ...

    @property
    def repositoryNames(self) -> jpype.JArray[java.lang.String]:
        ...

    @property
    def cancelled(self) -> jpype.JBoolean:
        ...

    @property
    def readOnly(self) -> jpype.JBoolean:
        ...

    @property
    def lastConnectError(self) -> java.lang.Throwable:
        ...

    @property
    def repository(self) -> RepositoryAdapter:
        ...

    @property
    def user(self) -> java.lang.String:
        ...


class RepositoryAdapter(RemoteAdapterListener):
    """
    ``RepositoryAdapter`` provides a persistent wrapper for a remote RepositoryHandle 
    which may become invalid if the remote connection were to fail.  Connection recovery is provided 
    by any method call which must communicate with the server.
    """

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, serverAdapter: RepositoryServerAdapter, name: typing.Union[java.lang.String, str]) -> None:
        """
        Construct.
        
        :param RepositoryServerAdapter serverAdapter: persistent server adapter
        :param java.lang.String or str name: repository name
        """

    def addListener(self, listener: RemoteAdapterListener) -> None:
        """
        Add a listener to this remote adapter
        
        :param RemoteAdapterListener listener:
        """

    def anonymousAccessAllowed(self) -> bool:
        """
        
        
        :return: true if anonymous access allowed by this repository
        :rtype: bool
        :raises IOException: if an IO error occurs
        """

    def checkout(self, folderPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str], checkoutType: ghidra.framework.store.CheckoutType, projectPath: typing.Union[java.lang.String, str]) -> ghidra.framework.store.ItemCheckoutStatus:
        ...

    def connect(self) -> None:
        """
        Attempt to connect to the server.
        
        :raises RepositoryNotFoundException: if named repository does not exist
        :raises IOException: if IO error occurs
        """

    def connectionStateChanged(self, adapter: java.lang.Object) -> None:
        """
        Notification callback when server connection state changes.
        
        
        .. seealso::
        
            | :obj:`ghidra.framework.client.RemoteAdapterListener.connectionStateChanged(java.lang.Object)`
        """

    def createDataFile(self, parentPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str]) -> None:
        ...

    def createDatabase(self, parentPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str], bufferSize: typing.Union[jpype.JInt, int], contentType: typing.Union[java.lang.String, str], fileID: typing.Union[java.lang.String, str], projectPath: typing.Union[java.lang.String, str]) -> db.buffers.ManagedBufferFileAdapter:
        ...

    def createTextDataFile(self, parentPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str], fileID: typing.Union[java.lang.String, str], contentType: typing.Union[java.lang.String, str], textData: typing.Union[java.lang.String, str], comment: typing.Union[java.lang.String, str]) -> None:
        ...

    def deleteItem(self, parentPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str], version: typing.Union[jpype.JInt, int]) -> None:
        ...

    def disconnect(self) -> None:
        ...

    def fileExists(self, folderPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str]) -> bool:
        ...

    def folderExists(self, folderPath: typing.Union[java.lang.String, str]) -> bool:
        ...

    def getCheckout(self, parentPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str], checkoutId: typing.Union[jpype.JLong, int]) -> ghidra.framework.store.ItemCheckoutStatus:
        ...

    def getCheckouts(self, parentPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str]) -> jpype.JArray[ghidra.framework.store.ItemCheckoutStatus]:
        ...

    @typing.overload
    def getItem(self, folderPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str]) -> ghidra.framework.remote.RepositoryItem:
        ...

    @typing.overload
    def getItem(self, fileID: typing.Union[java.lang.String, str]) -> ghidra.framework.remote.RepositoryItem:
        ...

    def getItemCount(self) -> int:
        ...

    def getItemList(self, folderPath: typing.Union[java.lang.String, str]) -> jpype.JArray[ghidra.framework.remote.RepositoryItem]:
        ...

    def getLength(self, parentPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str]) -> int:
        ...

    def getName(self) -> str:
        """
        Get the associated repository name
        
        :return: repository name
        :rtype: str
        """

    def getOpenFileHandleCount(self) -> int:
        ...

    def getServer(self) -> RepositoryServerAdapter:
        """
        Get the associated server adapter
        
        :return: server adapter
        :rtype: RepositoryServerAdapter
        """

    def getServerInfo(self) -> ghidra.framework.model.ServerInfo:
        """
        Returns associated server information
        
        :return: server information
        :rtype: ghidra.framework.model.ServerInfo
        """

    def getServerUserList(self) -> jpype.JArray[java.lang.String]:
        """
        Returns list of all user names known to server.
        
        :return: list of all user names known to server.
        :rtype: jpype.JArray[java.lang.String]
        :raises UserAccessException: user no longer has any permission to use repository.
        :raises NotConnectedException: if server/repository connection is down (user already informed)
        :raises IOException: if an IO error occurs
        
        .. seealso::
        
            | :obj:`RemoteRepositoryHandle.getServerUserList()`
        """

    def getSubfolderList(self, folderPath: typing.Union[java.lang.String, str]) -> jpype.JArray[java.lang.String]:
        ...

    def getUser(self) -> ghidra.framework.remote.User:
        """
        Returns repository connected user object.
        
        :return: connected user object
        :rtype: ghidra.framework.remote.User
        :raises UserAccessException: user no longer has any permission to use repository.
        :raises NotConnectedException: if server/repository connection is down (user already informed)
        :raises IOException: if an IO error occurs
        
        .. seealso::
        
            | :obj:`ghidra.framework.remote.RemoteRepositoryHandle.getUser()`
        """

    def getUserList(self) -> jpype.JArray[ghidra.framework.remote.User]:
        """
        Returns list of repository users with repository access permission
        
        :return: return users with repository access permission
        :rtype: jpype.JArray[ghidra.framework.remote.User]
        :raises UserAccessException: user no longer has any permission to use repository.
        :raises NotConnectedException: if server/repository connection is down (user already informed)
        :raises IOException: if an IO error occurs
        
        .. seealso::
        
            | :obj:`RemoteRepositoryHandle.getUserList()`
        """

    def getVersions(self, parentPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str]) -> jpype.JArray[ghidra.framework.store.Version]:
        ...

    def hadUnexpectedDisconnect(self) -> bool:
        """
        Returns true if connection recently was lost unexpectedly
        
        :return: true if connection recently was lost unexpectedly
        :rtype: bool
        """

    def hasCheckouts(self, parentPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str]) -> bool:
        ...

    def isCheckinActive(self, parentPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str]) -> bool:
        ...

    def isConnected(self) -> bool:
        """
        Returns true if connected.
        
        :return: true if connected.
        :rtype: bool
        """

    def moveFolder(self, oldParentPath: typing.Union[java.lang.String, str], newParentPath: typing.Union[java.lang.String, str], oldFolderName: typing.Union[java.lang.String, str], newFolderName: typing.Union[java.lang.String, str]) -> None:
        ...

    def moveItem(self, oldParentPath: typing.Union[java.lang.String, str], newParentPath: typing.Union[java.lang.String, str], oldItemName: typing.Union[java.lang.String, str], newItemName: typing.Union[java.lang.String, str]) -> None:
        ...

    def openDataFile(self, parentPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str], version: typing.Union[jpype.JInt, int]) -> ghidra.framework.store.DataFileHandle:
        ...

    @typing.overload
    def openDatabase(self, parentPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str], version: typing.Union[jpype.JInt, int], minChangeDataVer: typing.Union[jpype.JInt, int]) -> db.buffers.ManagedBufferFileAdapter:
        ...

    @typing.overload
    def openDatabase(self, parentPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str], checkoutId: typing.Union[jpype.JLong, int]) -> db.buffers.ManagedBufferFileAdapter:
        ...

    def removeListener(self, listener: RemoteAdapterListener) -> None:
        """
        Remove a listener from this remote adapter
        
        :param RemoteAdapterListener listener:
        """

    def setFileSystemListener(self, fsListener: ghidra.framework.store.FileSystemListener) -> None:
        """
        Set the file system listener associated with the remote repository.
        
        :param ghidra.framework.store.FileSystemListener fsListener: file system listener
        """

    def setUserList(self, users: jpype.JArray[ghidra.framework.remote.User], anonymousAccessAllowed: typing.Union[jpype.JBoolean, bool]) -> None:
        """
        Set the list of authorized users for this repository.
        
        :param jpype.JArray[ghidra.framework.remote.User] users: list of user and access permissions.
        :param jpype.JBoolean or bool anonymousAccessAllowed: true to permit anonymous access (also requires anonymous
        access to be enabled for server)
        :raises UserAccessException: user is not a repository Admin
        :raises IOException: if an IO error occurs
        :raises NotConnectedException: if server/repository connection is down (user already informed)
        
        .. seealso::
        
            | :obj:`RemoteRepositoryHandle.setUserList(User[], boolean)`
        """

    def terminateCheckout(self, folderPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str], checkoutId: typing.Union[jpype.JLong, int], notify: typing.Union[jpype.JBoolean, bool]) -> None:
        ...

    def updateCheckoutVersion(self, parentPath: typing.Union[java.lang.String, str], itemName: typing.Union[java.lang.String, str], checkoutId: typing.Union[jpype.JLong, int], checkoutVersion: typing.Union[jpype.JInt, int]) -> None:
        ...

    def verifyConnection(self) -> bool:
        """
        Verify that the connection is still valid.
        
        :return: true if the connection is valid; false if the connection needs to be reestablished
        :rtype: bool
        """

    @property
    def connected(self) -> jpype.JBoolean:
        ...

    @property
    def server(self) -> RepositoryServerAdapter:
        ...

    @property
    def item(self) -> ghidra.framework.remote.RepositoryItem:
        ...

    @property
    def userList(self) -> jpype.JArray[ghidra.framework.remote.User]:
        ...

    @property
    def serverInfo(self) -> ghidra.framework.model.ServerInfo:
        ...

    @property
    def subfolderList(self) -> jpype.JArray[java.lang.String]:
        ...

    @property
    def name(self) -> java.lang.String:
        ...

    @property
    def openFileHandleCount(self) -> jpype.JInt:
        ...

    @property
    def itemList(self) -> jpype.JArray[ghidra.framework.remote.RepositoryItem]:
        ...

    @property
    def serverUserList(self) -> jpype.JArray[java.lang.String]:
        ...

    @property
    def user(self) -> ghidra.framework.remote.User:
        ...

    @property
    def itemCount(self) -> jpype.JInt:
        ...


class RemoteAdapterListener(java.lang.Object):
    """
    ``RemoteAdapterListener`` provides a listener interface 
    which facilitates notifcation when the connection
    state of a remote server/repository adapter changes.
    """

    class_: typing.ClassVar[java.lang.Class]

    def connectionStateChanged(self, adapter: java.lang.Object) -> None:
        """
        Callback notification indicating the remote object
        connection state has changed.
        
        :param java.lang.Object adapter: remote interface adapter (e.g., RepositoryServerAdapter).
        """


@typing.type_check_only
class RepositoryChangeDispatcher(java.lang.Runnable):

    class_: typing.ClassVar[java.lang.Class]

    def setFileChangeListener(self, changeListener: ghidra.framework.store.FileSystemListener) -> None:
        ...

    def start(self) -> None:
        ...

    def stop(self) -> None:
        ...


class RepositoryNotFoundException(java.io.IOException):
    """
    ``RepositoryNotFoundException`` thrown when a failed connection occurs to a
    non-existing repository.  A valid server connection is required to make this 
    determination.
    """

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, msg: typing.Union[java.lang.String, str]) -> None:
        ...


class NotConnectedException(java.io.IOException):
    """
    ``NotConnectedException`` indicates that the server connection
    is down.  When this exception is thrown, the current operation should be
    aborted.  At the time this exception is thrown, the user has already been
    informed of a server error condition.
    """

    class_: typing.ClassVar[java.lang.Class]

    @typing.overload
    def __init__(self, msg: typing.Union[java.lang.String, str]) -> None:
        """
        Constructor.
        
        :param java.lang.String or str msg: error message
        """

    @typing.overload
    def __init__(self, msg: typing.Union[java.lang.String, str], cause: java.lang.Throwable) -> None:
        ...


class DefaultClientAuthenticator(docking.widgets.PopupKeyStorePasswordProvider, ClientAuthenticator):

    @typing.type_check_only
    class ServerPasswordPrompt(java.lang.Runnable):
        ...
        class_: typing.ClassVar[java.lang.Class]


    class_: typing.ClassVar[java.lang.Class]

    def __init__(self) -> None:
        ...

    @staticmethod
    def getMinimalURL(url: java.net.URL) -> java.net.URL:
        """
        Produce minimal URL (i.e., protocol, host and port)
        
        :param java.net.URL url: request URL
        :return: minimal URL
        :rtype: java.net.URL
        """


class DefaultGhidraUrlAllowListProvider(AbstractUrlAllowListProvider):
    """
    :obj:`DefaultGhidraUrlAllowListProvider` is an allow list provider for cases where 
    the user should be prompted when access has not yet been decided.
    
    
    Prompting uses ``stdin/stdout`` when :meth:`SystemUtilities.isInHeadlessMode() <SystemUtilities.isInHeadlessMode>` returns true,
    otherwise Swing GUI is used via :obj:`OptionDialog` popup.
    """

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self) -> None:
        ...


class HeadlessClientAuthenticator(ClientAuthenticator):
    """
    ``HeadlessClientAuthenticator`` provides the ability to install a Ghidra Server 
    authenticator needed when operating in a headless mode.
    """

    class_: typing.ClassVar[java.lang.Class]

    @staticmethod
    def getPassword(usage: typing.Union[java.lang.String, str], prompt: typing.Union[java.lang.String, str]) -> jpype.JArray[jpype.JChar]:
        """
        Prompt user on system console for a password entry.
        NOTE: Any returned password should be properly cleared when done using it.
        
        :param java.lang.String or str usage: text line before prompt (may be null)
        :param java.lang.String or str prompt: password prompt on same line as entry (required)
        :return: password entry
        :rtype: jpype.JArray[jpype.JChar]
        :raises IOException: if system console is unavailable and an error occurs reading from stdin
        """

    @staticmethod
    def installHeadlessClientAuthenticator(username: typing.Union[java.lang.String, str], keystorePath: typing.Union[java.lang.String, str], allowPasswordPrompt: typing.Union[jpype.JBoolean, bool]) -> None:
        """
        Install headless client authenticator for Ghidra Server and when http/https 
        connections require authentication and have not specified user information.
        
        :param java.lang.String or str username: optional username to be used with a Ghidra Server which
        allows username to be specified.  If null, :meth:`ClientUtil.getUserName() <ClientUtil.getUserName>` 
        will be used.
        :param java.lang.String or str keystorePath: optional PKI or SSH keystore path.  May also be specified
        as resource path for SSH key.
        :param jpype.JBoolean or bool allowPasswordPrompt: if true the user may be prompted for passwords
        via the console (stdin).  Please note that the Java console will echo 
        the password entry to the terminal which may be undesirable.
        :raises IOException: if error occurs while opening specified keystorePath
        """


class PasswordClientAuthenticator(ClientAuthenticator):
    """
    ``PasswordClientAuthenticator`` provides a fixed username/password 
    authentication response when connecting to any Ghidra Server or accessing
    a protected PKI keystore.  The use of this authenticator is intended for
    headless applications in which the user is unable to respond to such
    prompts.  SSH authentication is not currently supported.  Anonymous user
    access is not supported.
    
    
    If a PKI certificate has been installed, a password may be required 
    to access the certificate keystore independent of any other password which may be required
    for accessing SSH keys or server password authentication.  In such headless situations,
    the PKI certificate path/password should be specified via a property since it is unlikely
    that the same password will apply.
    
    
    .. seealso::
    
        | :obj:`DefaultKeyManagerFactory`
    """

    class_: typing.ClassVar[java.lang.Class]

    @typing.overload
    def __init__(self, password: typing.Union[java.lang.String, str]) -> None:
        ...

    @typing.overload
    def __init__(self, username: typing.Union[java.lang.String, str], password: typing.Union[java.lang.String, str]) -> None:
        ...


@typing.type_check_only
class ServerConnectTask(ghidra.util.task.Task):
    """
    Task for connecting to server with Swing thread.
    """

    @typing.type_check_only
    class ConnectCancelledListener(ghidra.util.task.CancelledListener, java.io.Closeable):
        ...
        class_: typing.ClassVar[java.lang.Class]


    @typing.type_check_only
    class FastConnectionFailSocket(java.net.Socket):
        """
        Socket implementation with very short connect timeout
        """

        class_: typing.ClassVar[java.lang.Class]


    class_: typing.ClassVar[java.lang.Class]

    @staticmethod
    def getGhidraServerHandle(server: ghidra.framework.model.ServerInfo, monitor: ghidra.util.task.TaskMonitor) -> ghidra.framework.remote.GhidraServerHandle:
        """
        Obtain a remote instance of the Ghidra Server Handle object
        
        :param ghidra.framework.model.ServerInfo server: server information
        :param ghidra.util.task.TaskMonitor monitor: cancellable monitor
        :return: Ghidra Server Handle object
        :rtype: ghidra.framework.remote.GhidraServerHandle
        :raises IOException: if a connection error occurs
        :raises CancelledException: if connection attempt was cancelled
        """

    def run(self, monitor: ghidra.util.task.TaskMonitor) -> None:
        """
        Completes and necessary authentication and obtains a repository handle.
        If a connection error occurs, an exception will be stored (:meth:`getException() <.getException>`.
        
        :raises CancelledException: if task cancelled
        
        .. seealso::
        
            | :obj:`ghidra.util.task.Task.run(ghidra.util.task.TaskMonitor)`
        """


class ServerSpecification(java.lang.Record, java.lang.Comparable[ServerSpecification]):
    """
    :obj:`ServerSpecification` URL-based server specification record
    """

    class_: typing.ClassVar[java.lang.Class]

    def __init__(self, protocol: typing.Union[java.lang.String, str], hostname: typing.Union[java.lang.String, str], port: typing.Union[jpype.JInt, int]) -> None:
        ...

    def equals(self, o: java.lang.Object) -> bool:
        ...

    @staticmethod
    def get(url: java.net.URL) -> ServerSpecification:
        ...

    def hashCode(self) -> int:
        ...

    def hostname(self) -> str:
        ...

    def port(self) -> int:
        ...

    def protocol(self) -> str:
        ...

    def toString(self) -> str:
        ...

    def toUrlString(self) -> str:
        """
        :return: server info in URL form
        :rtype: str
        """


class UrlAllowListManager(java.lang.Object):
    """
    :obj:`UrlAllowListManager` provides management of the Server URL Allow List persistent cache.
    """

    @typing.type_check_only
    class ServerAccessRecord(java.lang.Record):
        """
        :obj:`ServerAccessRecord` combines :obj:`ServerSpecification` and :obj:`AccessRecord` into 
        a single record for json serialization use only.
        """

        class_: typing.ClassVar[java.lang.Class]

        def accessAllowed(self) -> bool:
            ...

        def equals(self, o: java.lang.Object) -> bool:
            ...

        def hashCode(self) -> int:
            ...

        def hostname(self) -> str:
            ...

        def port(self) -> int:
            ...

        def protocol(self) -> str:
            ...

        def time(self) -> int:
            ...

        def toString(self) -> str:
            ...


    @typing.type_check_only
    class AllowListFile(java.lang.Record):
        """
        :obj:`AllowListFile` provides a json serialization wrapper with version to facilitate 
        storage in list form.
        """

        class_: typing.ClassVar[java.lang.Class]

        def allowList(self) -> java.util.List[UrlAllowListManager.ServerAccessRecord]:
            ...

        def equals(self, o: java.lang.Object) -> bool:
            ...

        def hashCode(self) -> int:
            ...

        def toString(self) -> str:
            ...

        def version(self) -> int:
            ...


    class_: typing.ClassVar[java.lang.Class]
    alwaysAllowLocalAccess: typing.ClassVar[jpype.JBoolean]

    @staticmethod
    def addChangeListener(listener: javax.swing.event.ChangeListener) -> None:
        """
        Add listener to be notified when allow list changes are made.
        NOTE: This is intended for Swing use only and notification will be provided within
        the Swing thread.
        
        :param javax.swing.event.ChangeListener listener: change listener
        """

    @staticmethod
    @typing.overload
    def clearAccessEntry(server: ServerSpecification) -> None:
        """
        Clear the access entry for the specified server.  This is intended to be used along with
        :meth:`getAccessMap() <.getAccessMap>` for managing the existing access map.
        Changes to ``localhost/127.0.0.1`` server access will be ignored if
        ``alwaysAllowLocalAccess`` is true.
        
        :param ServerSpecification server: server entry to be removed
        """

    @staticmethod
    @typing.overload
    def clearAccessEntry(url: java.net.URL) -> None:
        """
        Clear the access entry for the specified server URL. 
        Changes to ``localhost/127.0.0.1`` server access will be ignored if
        ``alwaysAllowLocalAccess`` is true.
        
        :param java.net.URL url: remote server URL (local and opaque URLs not permitted)
        """

    @staticmethod
    def clearAll() -> None:
        """
        Clear all server access entries.
        """

    @staticmethod
    @typing.overload
    def getAccess(protocol: typing.Union[java.lang.String, str], host: typing.Union[java.lang.String, str], port: typing.Union[jpype.JInt, int]) -> bool:
        """
        Determine if the specified server access is allowed.
        This method will return true for all ``localhost/127.0.0.1`` URLs if
        ``alwaysAllowLocalAccess`` is true.
        
        :param java.lang.String or str protocol: URL protocol
        :param java.lang.String or str host: server host
        :param jpype.JInt or int port: server port
        :return: true if server access is allowed, false if disallowed, null if no server entry was found
        :rtype: bool
        """

    @staticmethod
    @typing.overload
    def getAccess(url: java.net.URL) -> bool:
        """
        Determine if the specified server access is allowed.
        This method will return true for opaque or non-server URLs.
        This method will return true for all ``localhost/127.0.0.1`` URLs if 
        ``alwaysAllowLocalAccess`` is true.
        
        :param java.net.URL url: server URL
        :return: true if server access is allowed, false if disallowed, null if no server entry was found
        :rtype: bool
        """

    @staticmethod
    def getAccessMap() -> java.util.Map[ServerSpecification, AccessRecord]:
        """
        :return: copy of current server access map
        :rtype: java.util.Map[ServerSpecification, AccessRecord]
        """

    @staticmethod
    def removeChangeListener(listener: javax.swing.event.ChangeListener) -> None:
        """
        Remove existing change listener.
        
        :param javax.swing.event.ChangeListener listener: change listener
        """

    @staticmethod
    @typing.overload
    def updateAccess(protocol: typing.Union[java.lang.String, str], host: typing.Union[java.lang.String, str], port: typing.Union[jpype.JInt, int], allowAccess: typing.Union[jpype.JBoolean, bool]) -> None:
        """
        Update the access for the specified server within the cached allow list.
        Changes to ``localhost/127.0.0.1`` server access will be ignored if 
        ``alwaysAllowLocalAccess`` is true.
        
        :param java.lang.String or str protocol: URL protocol (e.g., ``https``, ``ghidra``, ``ghidra:<ext>``).
        :param java.lang.String or str host: host name or IP address
        :param jpype.JInt or int port: connection port (positive value)
        :param jpype.JBoolean or bool allowAccess: true allows access, false disallows access
        :raises java.lang.IllegalArgumentException: if an invalid parameter is specified
        """

    @staticmethod
    @typing.overload
    def updateAccess(url: java.net.URL, allowAccess: typing.Union[jpype.JBoolean, bool]) -> None:
        """
        Update the access for the specified server URL within the cached allow list.
        Changes to ``localhost/127.0.0.1`` server access will be ignored if
        ``alwaysAllowLocalAccess`` is true.
        
        :param java.net.URL url: remote server URL (local and opaque URLs not permitted)
        :param jpype.JBoolean or bool allowAccess: true allows access, false disallows access
        :raises java.lang.IllegalArgumentException: if an invalid, local or opaque URL is specified.
        """



__all__ = ["AbstractUrlAllowListProvider", "UrlAllowListProvider", "AccessRecord", "ClientAuthenticator", "ClientUtil", "RepositoryServerAdapter", "RepositoryAdapter", "RemoteAdapterListener", "RepositoryChangeDispatcher", "RepositoryNotFoundException", "NotConnectedException", "DefaultClientAuthenticator", "DefaultGhidraUrlAllowListProvider", "HeadlessClientAuthenticator", "PasswordClientAuthenticator", "ServerConnectTask", "ServerSpecification", "UrlAllowListManager"]
