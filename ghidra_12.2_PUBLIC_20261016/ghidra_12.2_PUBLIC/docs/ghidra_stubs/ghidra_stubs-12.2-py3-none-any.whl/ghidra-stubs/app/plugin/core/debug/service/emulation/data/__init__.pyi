from __future__ import annotations
import collections.abc
import datetime
import typing
from warnings import deprecated # type: ignore

import jpype # type: ignore
import jpype.protocol # type: ignore

import ghidra.debug.api.emulation
import ghidra.debug.api.modules
import ghidra.debug.api.target
import ghidra.framework.plugintool
import ghidra.pcode.exec_.trace.data
import ghidra.trace.model.guest


L = typing.TypeVar("L")
S = typing.TypeVar("S")
T = typing.TypeVar("T")


class AbstractPcodeDebuggerAccess(ghidra.pcode.exec_.trace.data.AbstractPcodeTraceAccess[S, L], ghidra.debug.api.emulation.PcodeDebuggerAccess, typing.Generic[S, L]):
    """
    An abstract implementation of :obj:`PcodeDebuggerAccess`
    """

    class_: typing.ClassVar[java.lang.Class]

    @typing.overload
    def __init__(self, target: ghidra.debug.api.target.Target, platform: ghidra.trace.model.guest.TracePlatform, snap: typing.Union[jpype.JLong, int]) -> None:
        """
        Construct a shim
        
        :param ghidra.debug.api.target.Target target: the target
        :param ghidra.trace.model.guest.TracePlatform platform: the associated platform, having the same trace as the recorder
        :param jpype.JLong or int snap: the associated snap
        """

    @typing.overload
    def __init__(self, target: ghidra.debug.api.target.Target, platform: ghidra.trace.model.guest.TracePlatform, snap: typing.Union[jpype.JLong, int], threadsSnap: typing.Union[jpype.JLong, int]) -> None:
        """
        Construct a shim
        
        :param ghidra.debug.api.target.Target target: the target
        :param ghidra.trace.model.guest.TracePlatform platform: the associated platform, having the same trace as the recorder
        :param jpype.JLong or int snap: the associated snap
        :param jpype.JLong or int threadsSnap: the snap to use when finding associated threads between trace and emulator
        """


class DefaultPcodeDebuggerAccess(AbstractPcodeDebuggerAccess[DefaultPcodeDebuggerMemoryAccess, DefaultPcodeDebuggerRegistersAccess]):
    """
    The default target-and-trace access shim for a session
    """

    class_: typing.ClassVar[java.lang.Class]

    @typing.overload
    def __init__(self, provider: ghidra.framework.plugintool.ServiceProvider, target: ghidra.debug.api.target.Target, platform: ghidra.trace.model.guest.TracePlatform, snap: typing.Union[jpype.JLong, int]) -> None:
        """
        Construct a shim
        
        :param ghidra.framework.plugintool.ServiceProvider provider: the service provider (usually the tool)
        :param ghidra.debug.api.target.Target target: the target
        :param ghidra.trace.model.guest.TracePlatform platform: the associated platform, having the same trace as the recorder
        :param jpype.JLong or int snap: the associated snap
        """

    @typing.overload
    def __init__(self, provider: ghidra.framework.plugintool.ServiceProvider, target: ghidra.debug.api.target.Target, platform: ghidra.trace.model.guest.TracePlatform, snap: typing.Union[jpype.JLong, int], threadsSnap: typing.Union[jpype.JLong, int]) -> None:
        """
        Construct a shim
        
        :param ghidra.framework.plugintool.ServiceProvider provider: the service provider (usually the tool)
        :param ghidra.debug.api.target.Target target: the target
        :param ghidra.trace.model.guest.TracePlatform platform: the associated platform, having the same trace as the recorder
        :param jpype.JLong or int snap: the associated snap
        :param jpype.JLong or int threadsSnap: the snap to use when finding associated threads between trace and emulator
        """


class DefaultPcodeDebuggerMemoryAccess(TranslatedPcodeDebuggerMemoryAccess):
    """
    The default data-and-debugger-access shim for session memory
    """

    class_: typing.ClassVar[java.lang.Class]


class TranslatedPcodeDebuggerMemoryAccess(ghidra.pcode.exec_.trace.data.DefaultPcodeTraceMemoryAccess, ghidra.debug.api.emulation.PcodeDebuggerMemoryAccess, InternalPcodeDebuggerDataAccess):
    """
    A data-and-debugger-access shim for memory with a provided :obj:`address translator <DebuggerAddressTranslator>`.
    """

    class_: typing.ClassVar[java.lang.Class]


class InternalPcodeDebuggerDataAccess(ghidra.pcode.exec_.trace.data.InternalPcodeTraceDataAccess):

    class_: typing.ClassVar[java.lang.Class]

    def getAddressTranslator(self) -> ghidra.debug.api.modules.DebuggerAddressTranslator:
        """
        :return: the address translator or null. If null is returned, then bytes cannot be loaded
        from mapped images.
        :rtype: ghidra.debug.api.modules.DebuggerAddressTranslator
        """

    def getTarget(self) -> ghidra.debug.api.target.Target:
        """
        :return: the target or null
        :rtype: ghidra.debug.api.target.Target
        """

    def isLive(self) -> bool:
        """
        Check if the associated trace represents a live target
        
        
        To be live, there must be a non-null target, that target must still be valid, i.e., connected
        to a live debugger, and the current snapshot must have a viewport incorporating the target's
        current snapshot.
        
        :return: true if alive or false if dead/offline
        :rtype: bool
        """

    @property
    def addressTranslator(self) -> ghidra.debug.api.modules.DebuggerAddressTranslator:
        ...

    @property
    def live(self) -> jpype.JBoolean:
        ...

    @property
    def target(self) -> ghidra.debug.api.target.Target:
        ...


class DefaultPcodeDebuggerRegistersAccess(ghidra.pcode.exec_.trace.data.DefaultPcodeTraceRegistersAccess, ghidra.debug.api.emulation.PcodeDebuggerRegistersAccess, InternalPcodeDebuggerDataAccess):
    """
    The default data-and-debugger access shim for session registers
    """

    class_: typing.ClassVar[java.lang.Class]


class DefaultPcodeDebuggerPropertyAccess(ghidra.pcode.exec_.trace.data.DefaultPcodeTracePropertyAccess[T], typing.Generic[T]):
    """
    The default trace-and-debugger-property access shim
    
    
    
    This implementation defers to the same property of mapped static images when the property is not
    set in the trace.
    """

    class_: typing.ClassVar[java.lang.Class]


class TranslatedPcodeDebuggerAccess(AbstractPcodeDebuggerAccess[TranslatedPcodeDebuggerMemoryAccess, DefaultPcodeDebuggerRegistersAccess]):
    """
    The default target-and-trace access shim for a session with a provided
    :obj:`address translator <DebuggerAddressTranslator>`.
    """

    class_: typing.ClassVar[java.lang.Class]

    @typing.overload
    def __init__(self, target: ghidra.debug.api.target.Target, platform: ghidra.trace.model.guest.TracePlatform, snap: typing.Union[jpype.JLong, int]) -> None:
        """
        Construct a shim
        
        :param ghidra.debug.api.target.Target target: the target
        :param ghidra.trace.model.guest.TracePlatform platform: the associated platform, having the same trace as the recorder
        :param jpype.JLong or int snap: the associated snap
        """

    @typing.overload
    def __init__(self, target: ghidra.debug.api.target.Target, platform: ghidra.trace.model.guest.TracePlatform, snap: typing.Union[jpype.JLong, int], threadsSnap: typing.Union[jpype.JLong, int]) -> None:
        """
        Construct a shim
        
        :param ghidra.debug.api.target.Target target: the target
        :param ghidra.trace.model.guest.TracePlatform platform: the associated platform, having the same trace as the recorder
        :param jpype.JLong or int snap: the associated snap
        :param jpype.JLong or int threadsSnap: the snap to use when finding associated threads between trace and emulator
        """

    def getAddressTranslator(self) -> ghidra.debug.api.modules.DebuggerAddressTranslator:
        """
        :return: the address translator or null. If null is returned, then bytes cannot be loaded
        from mapped images.
        :rtype: ghidra.debug.api.modules.DebuggerAddressTranslator
        
        
        
        .. seealso::
        
            | :obj:`InternalPcodeDebuggerDataAccess.getAddressTranslator()`
        """

    @property
    def addressTranslator(self) -> ghidra.debug.api.modules.DebuggerAddressTranslator:
        ...



__all__ = ["AbstractPcodeDebuggerAccess", "DefaultPcodeDebuggerAccess", "DefaultPcodeDebuggerMemoryAccess", "TranslatedPcodeDebuggerMemoryAccess", "InternalPcodeDebuggerDataAccess", "DefaultPcodeDebuggerRegistersAccess", "DefaultPcodeDebuggerPropertyAccess", "TranslatedPcodeDebuggerAccess"]
