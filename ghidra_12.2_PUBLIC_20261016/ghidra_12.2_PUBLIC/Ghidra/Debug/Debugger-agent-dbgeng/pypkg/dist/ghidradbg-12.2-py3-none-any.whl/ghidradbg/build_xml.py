## ###
# IP: GHIDRA
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
##
import os
import sys
rmi_path = os.getcwd() + "/../../../../../../Debugger-rmi-trace/src/main/py/src/ghidratrace/"
sys.path.append(rmi_path)
from merge_xml import merge


def main():
    xml = rmi_path+"xml/"
    merge(xml_base="dbgeng_base.xml",
          xml_out="schema.xml",
          xml_updates=[
              xml+"sessions.xml",
              xml+"common.xml",
              xml+"nesting_adjustments.xml",
              xml+"available.xml",
              xml+"events.xml",
              xml+"breakpointsFlat.xml"
          ])
    merge(xml_base="dbgeng_base.xml",
          xml_out="schema_exdi.xml",
          xml_updates=[
              xml+"sessions.xml",
              xml+"common.xml",
              xml+"nesting_adjustments.xml",
              xml+"available.xml",
              xml+"events.xml",
              xml+"breakpointsFlat.xml",
              os.getcwd()+"/exdi/exdi.xml"
          ])


if __name__ == '__main__':
    main()
